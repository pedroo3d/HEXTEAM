# HEXTEAM
PROP Projecte
Nom Equip: HEXTEAM Alumnes: Arquipelaro Pedro Reis Santiago - 12855446X //Ariel Median Aranibar - 26567855a 
URL GitHub: https://github.com/pedroo3d/HEXTEAM